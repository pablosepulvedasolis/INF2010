import java.util.List;

public class BinaryNode<T extends Comparable<? super T>> {
    private final T data;
    private BinaryNode<T> right;
    private BinaryNode<T> left;

    // TODO: initialisation
    // O(1)
    public BinaryNode(T data) {
        this.data = data;
        this.right = null;
        this.left = null;
    }

    // TODO: on retourne la donnee voulue
    // O(1)
    public T getData() {
        return this.data;
    }

    // TODO: on ajoute une nouvelle donnee au bon endroit
    // O(log(n))
    public void insert(T item) {
        if (item == null) {
            return;
        }
        BinaryNode<T> newItem = new BinaryNode<>(item);

        int compareResult = item.compareTo(this.data);
        if (compareResult <= 0) {
            if (this.left == null) {
                this.left = newItem;
            } else
                this.left.insert(item);
        } else {
            if (this.right == null) {
                this.right = newItem;
            } else
                this.right.insert(item);
        }
    }

    // TODO: est-ce que l'item fais partie du noeuds courant
    // O(log(n))
    public boolean contains(T item) {
        boolean contained = false;
        if (item == null) {
            return false;
        } else {
            int compareResult = item.compareTo(this.data);
            if (compareResult == 0) {
                return true;
            } else if (compareResult > 0) {
                if (this.right != null)
                    contained = this.right.contains(item);
            } else if (this.left != null)
                contained = this.left.contains(item);
        }
        return contained;
    }

    // TODO: on retourne la maximale de l'arbre
    // O(n)
    public int getHeight() {
        int leftHeight = 0;
        int currentHeight = 0;
        int maxHeight = 0;
        if (this.left != null) {
            maxHeight = this.left.getHeight() + 1;
        }
        if (this.right != null) {
            currentHeight = this.right.getHeight() + 1;
            maxHeight = Math.max(leftHeight, currentHeight);
        }
        return maxHeight;
    }

    // TODO: l'ordre d'insertion dans la liste est l'ordre logique
    // de manière que le plus petit item sera le premier inseré
    // O(n)
    public void fillListInOrder(List<BinaryNode<T>> result) {
        if (this.left != null) {
            this.left.fillListInOrder(result);
        }
        result.add(this);
        if (this.right != null) {
            this.right.fillListInOrder(result);
        }
    }
}